<?php 

	
	$arquivo_json = file_get_contents('json/candidatos.json');
	$array_candidatos = json_decode($arquivo_json, true);

     //Algoritmo para remover curtir
    if (isset($_POST['acao']) AND $_POST['acao'] == 'votar'){
        
        foreach ($array_candidatos as $pos => $candidato){
            if ($candidato['numero'] ==  $_POST['numero_candidato'] ){
                $array_candidatos[$pos]['votos'] ++;
            }
        }
        
        $array_candidatos = json_encode($array_candidatos, JSON_PRETTY_PRINT);
        file_put_contents("json/candidatos.json", $array_candidatos);
    }

    header("location: index.php");