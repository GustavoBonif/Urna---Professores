<!DOCTYPE html>
<html>
<head>
	<title> Lista com os votos</title>
</head>
<body>
	<tr>

		<?php 

		$arquivo_json = file_get_contents('json/candidatos.json');
		$array_candidatos = json_decode($arquivo_json, true);

		foreach ($array_candidatos as $candidato) { ?>

		<li> Número: <?= $candidato['numero'] ?> </li>
		<li> O professor <?= $candidato['nome'] ?> possui <?= $candidato['votos'] ?> votos </li>
		<li> <?= $candidato['partidos'] ?> </li>
		<li> <?= $candidato['mote'] ?> </li>
		<hr>

		<?php	
		}
		?>

	</tr>

</body>
</html>

