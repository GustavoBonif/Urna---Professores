<form>
<table cellpadding="2" cellspacing="2" border="0">
<tr>
      <td colspan="3" align="center"><input type="text" id="valor" onKeyPress="return(MascaraMoeda(this,'.',',',event))" size="35"></td>
          
</tr>
<tr>       
      <td><input type="button" value="  1  " style="font-size:25px;" onclick = "document.getElementById('valor').value = return(MascaraMoeda(this.value.'.',',',event))"></td>  
      <td><input type="button" value="  2  " style="font-size:25px;" onclick = "document.getElementById('valor').value = return(MascaraMoeda(this.value.'.',',',event))"></td>  
      <td><input type="button" value="  3  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>         
</tr>
<tr>
      <td><input type="button" value="  4  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>  
      <td><input type="button" value="  5  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>  
      <td><input type="button" value="  6  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>         
</tr>
<tr>
      <td><input type="button" value="  7  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>  
      <td><input type="button" value="  8  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>  
      <td><input type="button" value="  9  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>         
</tr>
<tr>
     <td><input type="button" value="  0  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>  

     <td><input type="button" value="  C  " style="font-size:25px;" onclick = "document.getElementById('valor').value =document.getElementById('valor').value+ this.value"></td>         
</tr>
</table>
</form>