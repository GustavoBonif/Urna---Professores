<!DOCTYPE html>
<html>
<head>
	<title>Painel Integrador</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>

	<section class="borda_principal">

		


		<section class="box_urna">
			
			<h1 class="cargo">Presidente</h1>

			<section id="margem_info">
				<h2 class="info">Número:</h2>
			</section>
				<form method="get" class="para_preencher" action="pagina_candidato.php">
					<input type="text" name="campo1" class="campo" value="" maxlength="1" autocomplete="off"  required>

					<input type="text" name="campo2" class="campo" maxlength="1" value="" autocomplete="off" oninput="this.form.submit();"  required>

					<embed height="0" type="audio/mpeg" width="0" src="urna_barulho.mp3" volume="60" loop="false" autostart="true" />
 
					<!--<input type="submit" name="confirma" value="confirma">

					<button> <a href="index.php"> clica aqui</a> </button>

					<meta http-equiv="refresh" content="url=index.php">
					
 				<input type="submit" name="enviar" class="enviar"> -->
				</form>


		</section>


		<br>
		<br>
		<br><br>
	<br>


	<!-- RODAP -->	
	<br>
	<br>
	<br>
	<hr>
	<br>
		 <h2>Aperta a tecla:</h2>
 		 <h1 class="verde">VERDE para CONFIRMAR este voto</h1>
		 <h1 class="laranja">LARANJA para REINICIAR este voto</h1>

	 <script type="text/javascript">
	 	
	 	//Send form if they hit enter.
		document.onkeypress = function () {
		  
		  	document.forms[].submit();
		  
		}
			
	</script>
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

	<a href="ranking.php">Ranking</a>
</section>
</body>
</html>

