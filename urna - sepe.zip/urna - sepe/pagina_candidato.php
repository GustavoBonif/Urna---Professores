<!DOCTYPE html>
<html>
<head>
	<title>Painel Integrador</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>


<?php 
	
	$arquivo_json = file_get_contents('json/candidatos.json');
	$array_candidatos = json_decode($arquivo_json, true);
	$contCandidato = 0;

	$candidatoEncontrado = [];

	$campo1 = $_GET['campo1'];
	$campo2 = $_GET['campo2'];

	$numero_candidato =  $campo1 .  $campo2;

	

	foreach ($array_candidatos as $candidato) {

		if ($numero_candidato == $candidato['numero']) {
			$candidatoEncontrado = $candidato;

			$contCandidato ++;
		?>

			<section class="candidato">
			<img class="foto" src="<?= $candidatoEncontrado['foto']?>">
		</section>	



		<section class="borda_principal">

		
			<section class="box_urna">
				<h2 class="votoPara"> Seu voto para</h2>
				<h1 class="cargo">Presidente</h1>

				<section id="margem_info">
					<h2 class="info">Número:</h2>
				</section>
					<form method="post" class="para_preencher" action="confirmar_voto.php">

						<input readonly="true" type="text" name="campo1" class="campo" value="<?= $_GET['campo1'] ?>" autocomplete="off">
						<input readonly="true" type="text" name="campo2" class="campo" value="<?= $_GET['campo2'] ?>" autocomplete="off">

						<input type="hidden" name="numero_candidato" value="<?= $numero_candidato ?>">	

						<input type="hidden" name="acao" value="votar">	

						<br><br>					

						<a href="index.php" autocomplete="off"><img class="botoesCorrige" src="img/Urna_Eletrônica_Corrige.gif"></a>	

						<button type="submit" class="botaoConfirma" name="confirma">
							<img class="botoesConfirma"  src="img/Urna_Eletrônica_Confirma.gif">							
						</button>									
						
					</form>

				<div style="clear: both;"></div>

				<section id="margem_info">
					<h2 class="info">Nome: <?= $candidatoEncontrado['nome'] ?></h2>
				</section>

				<div style="clear: both;"></div>

				<section id="margem_info">
					<h2 class="info">Partido: <?= $candidatoEncontrado['partidos'] ?></h2>
				</section>	

				<section id="margem_info">
					<h2 class="info">Votos: <?= $candidatoEncontrado['votos'] ?></h2>
				</section>	

			<?php	

	
					}
		
			}
			if ($contCandidato == 0) { ?>

					<br><br><br><br><br><br><br>

						<h2 class="votoPara"> NÚMERO ERRADO</h2>

				
					<br><br>
				</section>
				<br><br><br><br><br><br><br><br>
				<p class="votoNulo"> VOTO NULO</p>
				<button class="botao_voltar">
					<a class="link_voltar" href="index.php">voltar</a>
				</button>

			<?php

			}

			?>

			</section>

		<hr>
			 <h2>Aperta a tecla:</h2>
	 		 <h1 class="verde">VERDE para CONFIRMAR este voto</h1>
			 <h1 class="laranja">LARANJA para REINICIAR este voto</h1>
	 

</body>
</html>